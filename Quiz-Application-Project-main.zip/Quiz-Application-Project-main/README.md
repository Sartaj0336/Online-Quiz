# Quiz-Application-Project
This is Desktop Quiz Application Build on Java. This is Our 2nd Semester Project based on OOP's Concept
